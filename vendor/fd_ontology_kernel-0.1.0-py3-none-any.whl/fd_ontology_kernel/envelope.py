"""Portable asset envelopes: carry one audited asset version between instances.

A published version is immutable *inside* one instance; an envelope is how the
same content travels. The two share one digest (``manifest.digest_of`` over the
canonical payload) so "is this copy that version" has one answer.

Five asset kinds, one shape::

    kind: ontology-template | vocabulary-release | ruler-set | gold-set | eval-suite
    payload: the asset's own canonical content (see build_payload)
    manifest_shape: interpretation of the payload, NEVER inside it
    digest: hex sha256 of the payload (no prefix, equals a publication digest)
    lineage: {"upstream": {"name","version","digest"}} for a fork, else absent
    fork_diff: required whenever lineage is present
    files: [{"path", "sha256"}] for large side files (corpus stays by reference)

This module is deliberately outside the six-port contract: it opens nothing,
stores nothing, and raises ``EnvelopeError`` (a plain ``ValueError``) rather
than adding an ``ErrorCode`` — adding one would bump the kernel contract for a
utility no adapter implements.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping, Optional

from . import manifest, vocab

#: Asset kinds an envelope may carry. Closed: an unknown kind is named, refused.
ASSET_KINDS: tuple[str, ...] = (
    "ontology-template",
    "vocabulary-release",
    "ruler-set",
    "gold-set",
    "eval-suite",
)

#: Envelope format version. Distinct from ``manifest_shape`` (payload shape).
ENVELOPE_FORMAT = 1

#: Hex digest prefix used where a value must be recognizable as a digest.
DIGEST_PREFIX = "sha256:"


class EnvelopeError(ValueError):
    """An envelope is malformed, tampered with, or missing required lineage."""


@dataclass(frozen=True)
class AssetEnvelope:
    """A validated envelope. Frozen: a digest that can change is not a digest."""

    kind: str
    name: str
    version: int
    manifest_shape: int
    digest: str
    payload: Mapping[str, Any]
    lineage: Optional[Mapping[str, Any]]
    fork_diff: Optional[Mapping[str, Any]]
    files: tuple[Mapping[str, str], ...]

    @property
    def is_fork(self) -> bool:
        return self.lineage is not None


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _is_plain_object(value: Any) -> bool:
    return isinstance(value, dict) and not isinstance(value, list)


def _nonempty_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def lineage_problem(lineage: Any) -> Optional[str]:
    """Why ``lineage`` is not a usable upstream pointer (``None`` = fine).

    Absent lineage is legal (a use, not a fork). Present lineage must name the
    upstream's name, integer version, and digest — a fork that cannot say which
    version it came from is indistinguishable from the parent forever.
    """
    if lineage is None:
        return None
    if not _is_plain_object(lineage):
        return "lineage must be an object of {upstream: {name, version, digest}}"
    upstream = lineage.get("upstream")
    if not _is_plain_object(upstream):
        return "lineage.upstream must be an object of {name, version, digest}"
    for key in ("name", "digest"):
        if not _nonempty_text(upstream.get(key)):
            return f"lineage.upstream.{key} must be a non-empty string"
    version = upstream.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        return "lineage.upstream.version must be a positive integer"
    return None


def validate(raw: Any) -> list[str]:
    """Structural problems with an envelope (empty list = well formed).

    Shape only: the payload is not interpreted and files are not hashed here —
    :func:`verify` does that. Like the rest of this package, problems are named
    per path rather than folded into one string.
    """
    problems: list[str] = []
    if not _is_plain_object(raw):
        return [f"envelope must be an object, got {type(raw).__name__}"]

    kind = raw.get("kind")
    if kind not in ASSET_KINDS:
        problems.append(
            f"kind {kind!r} is not a portable asset kind; allowed: {list(ASSET_KINDS)}"
        )

    for key in ("name", "digest"):
        if not _nonempty_text(raw.get(key)):
            problems.append(f"{key} must be a non-empty string")

    version = raw.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        problems.append("version must be a positive integer")

    shape = raw.get("manifest_shape")
    if isinstance(shape, bool) or not isinstance(shape, int):
        problems.append("manifest_shape must be an integer")
    elif shape not in manifest.SUPPORTED_SHAPES:
        problems.append(
            f"manifest_shape {shape} is not supported; supported: "
            f"{sorted(manifest.SUPPORTED_SHAPES)}"
        )

    payload = raw.get("payload")
    if not _is_plain_object(payload):
        problems.append("payload must be an object")

    lineage = raw.get("lineage")
    if lineage is not None:
        if not _is_plain_object(lineage) or not _is_plain_object(lineage.get("upstream")):
            problems.append(
                "lineage must be an object of {upstream: {name, version, digest}}"
            )
        else:
            upstream = lineage["upstream"]
            for key in ("name", "digest"):
                if not _nonempty_text(upstream.get(key)):
                    problems.append(
                        f"lineage.upstream.{key} must be a non-empty string"
                    )
            version = upstream.get("version")
            if isinstance(version, bool) or not isinstance(version, int) or version < 1:
                problems.append("lineage.upstream.version must be a positive integer")
            fork_diff = raw.get("fork_diff")
            if not _is_plain_object(fork_diff) or not fork_diff:
                problems.append(
                    "a fork must record fork_diff (a non-empty object saying how it "
                    "differs from its upstream); a silent copy cannot be told apart "
                    "from the parent forever"
                )

    files = raw.get("files", [])
    if not isinstance(files, list):
        problems.append("files must be a list of {path, sha256}")
    else:
        seen: set[str] = set()
        for i, entry in enumerate(files):
            path = f"files[{i}]"
            if not _is_plain_object(entry):
                problems.append(f"{path} must be an object of {{path, sha256}}")
                continue
            if not _nonempty_text(entry.get("path")):
                problems.append(f"{path}.path must be a non-empty string")
            elif entry["path"] in seen:
                problems.append(f"{path}.path {entry['path']!r} is declared twice")
            else:
                seen.add(entry["path"])
            if not _nonempty_text(entry.get("sha256")):
                problems.append(f"{path}.sha256 must be a non-empty string")

    return problems


def build(
    *,
    kind: str,
    name: str,
    version: int,
    payload: Mapping[str, Any],
    manifest_shape: int,
    lineage: Optional[Mapping[str, Any]] = None,
    fork_diff: Optional[Mapping[str, Any]] = None,
    files: Optional[list[Mapping[str, str]]] = None,
) -> dict[str, Any]:
    """Assemble an envelope, computing the content digest over the payload.

    The digest is bare hex so it is byte-equal to a publication digest of the
    same content. Callers that want the display prefix use
    :func:`prefixed_digest`.
    """
    raw: dict[str, Any] = {
        "format": ENVELOPE_FORMAT,
        "kind": kind,
        "name": name,
        "version": version,
        "manifest_shape": manifest_shape,
        "digest": manifest.digest_of(payload),
        "payload": dict(payload),
        "files": list(files or []),
    }
    if lineage is not None:
        raw["lineage"] = dict(lineage)
    if fork_diff is not None:
        raw["fork_diff"] = dict(fork_diff)
    problems = validate(raw)
    if problems:
        raise EnvelopeError("invalid envelope: " + "; ".join(problems))
    return raw


def verify(raw: Any, *, file_bytes: Optional[Mapping[str, bytes]] = None) -> AssetEnvelope:
    """Validate, then check the digest and every declared side file.

    Any mismatch raises — an envelope is accepted whole or not at all. When
    ``files`` is non-empty, ``file_bytes`` must supply every declared path: an
    unverifiable file is a refusal, not a skip (skipped is not passed).
    """
    problems = validate(raw)
    if problems:
        raise EnvelopeError("invalid envelope: " + "; ".join(problems))

    expected = manifest.digest_of(raw["payload"])
    if raw["digest"] != expected:
        raise EnvelopeError(
            f"envelope digest {raw['digest']!r} does not match its payload "
            f"({expected!r}); the content was changed after it was digested"
        )

    files = raw.get("files") or []
    if files:
        if file_bytes is None:
            raise EnvelopeError(
                "envelope declares side files but no file bytes were supplied; "
                "an unverifiable file is refused, not skipped"
            )
        missing = [f["path"] for f in files if f["path"] not in file_bytes]
        if missing:
            raise EnvelopeError(f"declared files are missing: {missing}")
        for entry in files:
            actual = _sha256_hex(file_bytes[entry["path"]])
            if actual != entry["sha256"]:
                raise EnvelopeError(
                    f"file {entry['path']!r} sha256 {actual} does not match the "
                    f"declared {entry['sha256']!r}"
                )

    return AssetEnvelope(
        kind=raw["kind"],
        name=raw["name"],
        version=raw["version"],
        manifest_shape=raw["manifest_shape"],
        digest=raw["digest"],
        payload=dict(raw["payload"]),
        lineage=dict(raw["lineage"]) if raw.get("lineage") is not None else None,
        fork_diff=dict(raw["fork_diff"]) if raw.get("fork_diff") is not None else None,
        files=tuple(dict(f) for f in files),
    )


def prefixed_digest(digest: str) -> str:
    """``sha256:<hex>`` for display; never hashed again."""
    value = (digest or "").strip()
    if not value:
        raise EnvelopeError("a digest cannot be empty")
    return value if value.startswith(DIGEST_PREFIX) else DIGEST_PREFIX + value


def vocabulary_from_release(payload: Mapping[str, Any]) -> vocab.Vocabulary:
    """Build a kernel ``Vocabulary`` from a ``vocabulary-release`` payload.

    Payload shape::

        {"release": "2026.11", "sets": {"entity_types": ["company", ...],
                                        "relationship_kinds": ["belongs_to", ...]}}

    A set may also be an object ``{"values": [...], "superseded_by": {v: v2}}``.
    Unknown shapes are refused; this helper never invents a release.
    """
    if not _is_plain_object(payload):
        raise EnvelopeError("vocabulary-release payload must be an object")
    release = payload.get("release")
    if not _nonempty_text(release):
        raise EnvelopeError("vocabulary-release payload needs a non-empty release")
    sets = payload.get("sets")
    if not _is_plain_object(sets) or not sets:
        raise EnvelopeError("vocabulary-release payload needs a non-empty sets object")

    built: dict[str, vocab.VocabularySet] = {}
    for set_name, raw_set in sets.items():
        if isinstance(raw_set, list):
            values = list(raw_set)
            superseded: dict[str, str] = {}
        elif _is_plain_object(raw_set) and isinstance(raw_set.get("values"), list):
            values = list(raw_set["values"])
            superseded = dict(raw_set.get("superseded_by") or {})
        else:
            raise EnvelopeError(
                f"vocabulary set {set_name!r} must be a list or {{values, superseded_by}}"
            )
        entries = {
            str(value): vocab.Entry(
                id=str(value),
                set_name=set_name,
                label_en=str(value),
                label_zh=str(value),
                superseded_by=(
                    str(superseded[str(value)]) if str(value) in superseded else None
                ),
            )
            for value in values
        }
        built[str(set_name)] = vocab.VocabularySet(
            name=str(set_name), values=tuple(str(v) for v in values), entries=entries
        )
    return vocab.Vocabulary(release=str(release), sets=built)


def additive_problem(
    previous: Optional[vocab.Vocabulary], current: vocab.Vocabulary
) -> Optional[str]:
    """Why importing ``current`` over ``previous`` is not additive (``None`` = fine).

    Delegates to the kernel rule (``vocab.assert_additive``) so a second
    implementation cannot drift; returns the reason instead of raising for
    callers that collect problems.
    """
    try:
        vocab.assert_additive(previous, current)
    except vocab.VocabEntryRemoved as exc:
        return str(exc.message if hasattr(exc, "message") else exc)
    return None


def load_json(text: str) -> dict[str, Any]:
    """Parse an envelope JSON document (a convenience for CLI/tests)."""
    data = json.loads(text)
    if not _is_plain_object(data):
        raise EnvelopeError("envelope document must be a JSON object")
    return data
